package com.chinasofti.vtcsvc.facade.idvalidator.util;

import java.util.Scanner;


/**
 * 该类需要和里面牵扯到的Des2.java，RSABase64.java，RSAEncrypt.java 三个类打包成一个jar包
 * 然后用在cmd 命令行中 输入 java -jar jar包名称.jar
 * 然后生成秘钥对或者加密字段
 * 生成密钥对，加密数据的工具 完成功能： 输入 1) 密钥以及加密后生成文件的存放地址 2) 需要加密的字符串 3) 加密字符串的文件名
 * 
 * 输出(需要工作人员将1，2 放入resposip文件夹内，需要将3文件内的字段复制，粘贴到对应的文件) 1) 私钥文件(经过DES加密后的字符串文件)
 * 2) 公钥文件(经过DES加密后的字符串文件) 3) 加密字符串(经过RSA加密后的字符串文件)
 *
 */
public class RSAScrambler {

	public static final String TITLE_WELCOME = "************ 欢迎使用RSA加密工具 ****************";
	public static final String TIP_CHOOSE = "---请选择: 1 生成秘钥对  2 加密字段 ---";
	
	public static void main(String[] args) throws Exception {
		RSAScrambler m = new RSAScrambler();
		m.start();
	}

	public void start() throws Exception{
		boolean ifContinue = true;
		System.out.println(TITLE_WELCOME);
		Scanner scan = new Scanner(System.in);
		
		while(ifContinue){
			
			System.out.println(TIP_CHOOSE);
			String judgmentString = scan.nextLine();
			if("1".equals(judgmentString)){
				System.out.println("---请输入文件存放地址(用于存放生成公钥密钥及加密字符串的文件)---");
				this.generateKeyPair(scan.nextLine());
			}else if("2".equals(judgmentString)){
				System.out.println("---请输入公钥文件的地址---");
				String keypath = scan.nextLine();
				System.out.println("---请输入待加密的字段---");
				String toBeEncryptedFields = scan.nextLine();
				System.out.println("---请输入加密字段存放的文件名---");
				String toBeEncryptedStringName = scan.nextLine();
				this.decryptFieldByPublickey(keypath, toBeEncryptedFields, toBeEncryptedStringName);
			}else{
				// 关闭输入流
				if (null != scan) {
					scan.close();
				}
				
				return;
			}
			
			System.out.println("---是否回到功能选择部分(1  回到功能选择部分  2  退出(其他键可退出) )----");
			if(!"1".equals(scan.nextLine())){
				ifContinue = false;
			}
		}
		// 关闭输入流
		if (null != scan) {
			scan.close();
		}
	}
	
	

	/**
	 *  使用公钥加密字段
	 * @param keypath
	 * @param toBeEncryptedFields
	 * @param toBeEncryptedStringName
	 * @throws Exception
	 */
	public void decryptFieldByPublickey(String keypath,String toBeEncryptedFields,String toBeEncryptedStringName) throws Exception {
		

		String publickeyString = RSAEncrypt.loadPublicKeyByFile(keypath);
		byte[] cipherData = RSAEncrypt.encrypt(RSAEncrypt.loadPublicKeyByStr(publickeyString),
				toBeEncryptedFields.getBytes());
		String cipher = RSABase64.encode(cipherData);
		RSAEncrypt.saveTextByPath(keypath + "/" + toBeEncryptedStringName, cipher);

	}
	
	/**
	 *  根据文件路径生成密钥对
	 * @param filePath
	 */
	public void generateKeyPair(String filePath){
		System.out.println("---您输入的路径为:" + filePath);
		System.out.println("---开始生生成公钥密钥...");
		RSAEncrypt.genKeyPair(filePath);
		System.out.println("---生成公钥密钥成功....");
	}
}
