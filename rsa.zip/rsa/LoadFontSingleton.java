package com.chinasofti.vtcsvc.facade.idvalidator.impl;

import java.awt.Font;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

public class LoadFontSingleton {

	private static final Logger logger = LoggerFactory.getLogger(LoadFontSingleton.class);
	private static volatile Font instance = null;
	private LoadFontSingleton() {
	}
	public static Font getIstance() {
		if (instance == null) {
			synchronized (logger) {
				if (instance == null) {
					instance = loadFont();
				}
			}
		}
		return instance;
	}

	private static Font loadFont() {
		FileInputStream fi = null;
		BufferedInputStream fb = null;
		Font instance = null;
		try {
			String filePath = "font/customerFont.ttf";
			ClassPathResource resource = new ClassPathResource(filePath);
			File f = resource.getFile();
			if (f.exists()) {
				fi = new FileInputStream(f);
				fb = new BufferedInputStream(fi);
				instance = Font.createFont(Font.TRUETYPE_FONT, fb);
				logger.debug("第一次调用加载,生成缓存font文件");
			}
		} catch (Exception e) {
			logger.error("读取字体文件出错", e);
		} finally {
			if (fi != null) {
				try {
					fi.close();
				} catch (IOException e) {
					logger.error("关闭流fi出错", e);
				}
			}
			if (fb != null) {
				try {
					fb.close();
				} catch (IOException e) {
					logger.error("关闭流fb出错", e);
				}
			}
		}
		return instance;
	}
}