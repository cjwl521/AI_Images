package com.chinasofti.vtcsvc.business;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import com.chinasofti.vtcsvc.business.client.UploadPdfServiceImpl;

public class PdfUploadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		UploadPdfServiceImpl upload = new UploadPdfServiceImpl();
		
		byte[] file = readFileData("D:/pdftest/Amy/download/MyBatis.pdf");
		
		upload.getUploadPdfServiceImplPort().uploadPdf(file, "54321", "test8", "");
		
	}

	/**
	 * 读取文件内容
	 * 
	 * @param filePath
	 * @return
	 */
	public static byte[] readFileData(String filePath) {

		File file = new File(filePath);
		FileInputStream fis = null;

		byte[] retByte = new byte[(int) file.length()];
		try {
			fis = new FileInputStream(file);
			fis.read(retByte);
			fis.close();
		} catch (Exception e) {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e1) {
				}
			}
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
				}
			}
		}

		return retByte;
	}
}
