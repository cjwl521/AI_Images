@javax.xml.bind.annotation.XmlSchema(namespace = "http://business.vtcsvc.chinasofti.com/")
package com.chinasofti.vtcsvc.business.client;
