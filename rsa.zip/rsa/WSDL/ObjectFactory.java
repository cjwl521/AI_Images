
package com.chinasofti.vtcsvc.business.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.demo.client package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UploadPdfResponse_QNAME = new QName("http://business.vtcsvc.chinasofti.com/", "uploadPdfResponse");
    private final static QName _UploadPdf_QNAME = new QName("http://business.vtcsvc.chinasofti.com/", "uploadPdf");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.demo.client
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UploadPdfResponse }
     * 
     */
    public UploadPdfResponse createUploadPdfResponse() {
        return new UploadPdfResponse();
    }

    /**
     * Create an instance of {@link UploadPdf }
     * 
     */
    public UploadPdf createUploadPdf() {
        return new UploadPdf();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadPdfResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business.vtcsvc.chinasofti.com/", name = "uploadPdfResponse")
    public JAXBElement<UploadPdfResponse> createUploadPdfResponse(UploadPdfResponse value) {
        return new JAXBElement<UploadPdfResponse>(_UploadPdfResponse_QNAME, UploadPdfResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UploadPdf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business.vtcsvc.chinasofti.com/", name = "uploadPdf")
    public JAXBElement<UploadPdf> createUploadPdf(UploadPdf value) {
        return new JAXBElement<UploadPdf>(_UploadPdf_QNAME, UploadPdf.class, null, value);
    }

}
