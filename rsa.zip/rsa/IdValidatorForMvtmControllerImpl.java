package com.chinasofti.vtcsvc.facade.idvalidator.impl;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.util.Date;
import java.util.Locale;

import javax.imageio.ImageIO;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.Assert;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.chinasofti.vtcsvc.business.util.Base64Dec;
import com.chinasofti.vtcsvc.facade.idvalidator.IdValidatorForMvtmController;
import com.chinasofti.vtcsvc.facade.idvalidator.bean.DataSource;
import com.chinasofti.vtcsvc.facade.idvalidator.bean.Id5NewDO;
import com.chinasofti.vtcsvc.facade.idvalidator.bean.IdValidatorVO;
import com.chinasofti.vtcsvc.facade.idvalidator.bean.PoliceCheckInfo;
import com.chinasofti.vtcsvc.facade.idvalidator.bean.PoliceCheckInfos;
import com.chinasofti.vtcsvc.facade.idvalidator.util.JaxbUtil;
import com.chinasofti.vtcsvc.facade.idvalidator.util.RSABase64;
import com.chinasofti.vtcsvc.facade.idvalidator.util.RSAEncrypt;
import com.chinasofti.vtcsvc.messaging.util.Des2;
import com.chinasofti.vtmsln.config.ExtendedMessageSource;
import com.chinasofti.vtmsln.exception.BusinessException;
import com.chinasofti.vtmsln.model.BaseResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(path = "/idValidatorForMvtm")
public class IdValidatorForMvtmControllerImpl implements IdValidatorForMvtmController {

	private static final String VALIDATOR_KEY = "validatorKey";
	private static final String VALIDATOR_USERNAME = "validatorUsername";
	private static final String VALIDATOR_PASSWORD = "validatorPassword";
	private static final String VALIDATOR_DATASOURCE = "validatorDatasource";
	private static final String VALIDATOR_PROXY = "validatorproxy";
	private static final String VALIDATOR_PORT = "validatorport";
	private static final String VALIDATOR_URL = "validatorurl";
	private static final String VALIDATOR_DUMMY = "validatordummy";
	private static final String RSAPRIVATEKEY_PATH = "/repository/rsa/rsaprivatekey";
	private static final String ID50001 = "ID50001";
	private static final String REPOSITORY_TEMP = "/repository/temp";
	private static final String SERVICE_CONTENT = "/group-vtm-sln-content-service/service/content";
	private static final String UPLOAD = "mvtmupload";
	private static final String ID5URL = "https://uat1-vtm-ids-cn.hk.hsbc:30001/id5/service/id5/originalQuery"; // 根据不同环境填写不同路径

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	@Qualifier("validatorMessageSource")
	private ExtendedMessageSource validatorMessageSource;

	@Autowired
	@Qualifier("rsaprivateMessageSource")
	private ExtendedMessageSource rsaprivateMessageSource;

	@Autowired
	@Qualifier(value = "contentRepositoryRootPath")
	private String contentRepositoryRootPath;

	@Autowired
	@Qualifier("privateRSAPart2")
	private String privateRSAPart2;

	@Autowired
	private CloseableHttpClient httpclient;

	private CloseableHttpClient httpNewClient;

	/**
	 * 查询身份证合法性根据身份证号及姓名查询
	 */
	@Override
	@RequestMapping(path = "/idCheck", method = RequestMethod.POST)
	public BaseResponse idValidator(@RequestBody IdValidatorVO idValidatorVO, HttpServletRequest request) {

		Assert.notNull(idValidatorVO,
				"[Assertion VO] - this argument [idValidatorVO] is required; it must not be null");
		Assert.notNull(idValidatorVO.getFullName(),
				"[Assertion failed] - this argument [fullName] is required; it must not be null");
		Assert.notNull(idValidatorVO.getiDNumber(),
				"[Assertion failed] - this argument [iDNumber] is required; it must not be null");
		BaseResponse baseResponse = new BaseResponse();
		DataSource vo = this.queryByIdAndName(idValidatorVO.getiDNumber(), idValidatorVO.getFullName());
		baseResponse.getData().add(vo);
		return baseResponse;
	}

	@Override
	@RequestMapping(path = "/idCheckNew", method = RequestMethod.POST)
	public BaseResponse idValidatorNew(@RequestBody IdValidatorVO idValidatorVO, HttpServletRequest request) {

		Assert.notNull(idValidatorVO,
				"[Assertion VO] - this argument [idValidatorVO] is required; it must not be null");
		Assert.notNull(idValidatorVO.getFullName(),
				"[Assertion failed] - this argument [fullName] is required; it must not be null");
		Assert.notNull(idValidatorVO.getiDNumber(),
				"[Assertion failed] - this argument [iDNumber] is required; it must not be null");
		BaseResponse baseResponse = new BaseResponse();
		DataSource vo = this.queryByIdAndNameNewId5Service(idValidatorVO.getiDNumber(), idValidatorVO.getFullName());
		baseResponse.getData().add(vo);
		return baseResponse;
	}

	/**
	 * 通过身份证号和姓名查询
	 * 
	 * @param idCard
	 * @param fullName
	 * @return
	 */

	private DataSource queryByIdAndName(String idCard, String fullName) {
		String validatorKey = validatorMessageSource.getMessage(VALIDATOR_KEY, null, Locale.ROOT);
		String validatorUsername = validatorMessageSource.getMessage(VALIDATOR_USERNAME, null, Locale.ROOT);
		String validatorPassword = validatorMessageSource.getMessage(VALIDATOR_PASSWORD, null, Locale.ROOT);

		String validatorDatasource = validatorMessageSource.getMessage(VALIDATOR_DATASOURCE, null, Locale.ROOT);
		String validatorproxy = validatorMessageSource.getMessage(VALIDATOR_PROXY, null, Locale.ROOT);
		String validatorport = validatorMessageSource.getMessage(VALIDATOR_PORT, null, Locale.ROOT);
		String validatorurl = validatorMessageSource.getMessage(VALIDATOR_URL, null, Locale.ROOT);
		String validatordummy = validatorMessageSource.getMessage(VALIDATOR_DUMMY, null, Locale.ROOT);
		HttpEntity entity = null;
		DataSource dataSource = null;
		CloseableHttpResponse response = null;
		try {
			if ("true".equals(validatordummy)) {
				dataSource = JaxbUtil.converyToJavaBean(this.getXml(idCard, fullName), DataSource.class);
			} else {

				String userName = Des2.encode(validatorKey, validatorUsername);
				// 该部分获取秘钥和密文进行解密
				// 1. 从文件中获取秘钥对象
				String privateRSAKey = RSAEncrypt.loadPrivateKeyByFile(contentRepositoryRootPath + RSAPRIVATEKEY_PATH,
						privateRSAPart2);
				RSAPrivateKey privateKey = RSAEncrypt.loadPrivateKeyByStr(privateRSAKey);
				// 2. 使用秘钥对象和解密的字符串进行再次解密
				byte[] desValidatorPasswordString = RSAEncrypt.decrypt(privateKey, RSABase64.decode(validatorPassword));
				// 3. 将解密的数据转换成字符串
				String idvpassword = new String(desValidatorPasswordString);
				String idvpasswordBase64 = Base64Dec.base64DecMethod(idvpassword);
				logger.info("Decrypted validatorpassword success");
				// 4. 将字符串数据进行加密用来进行网络传输
				String password = Des2.encode(validatorKey, idvpasswordBase64);
				String datasource = Des2.encode(validatorKey, validatorDatasource);
				String param = fullName + "," + idCard;
				param = Des2.encode(validatorKey, param);
				String params = "<?xml version=\"1.0\" ?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">"
						+ "<S:Body><querySingle xmlns=\"http://app.service.validator.businesses.gboss.id5.cn\">"
						+ "<userName_>" + userName + "</userName_>" + "<password_>" + password + "</password_>"
						+ "<type_>" + datasource + "</type_>" + "<param_>" + param + "</param_>"
						+ "</querySingle></S:Body></S:Envelope>";
				logger.debug(params);

				HttpPost request = new HttpPost(validatorurl);
				request.addHeader("SOAPAction", "");
				request.setEntity(new StringEntity(params));
				// 使用代理
				HttpHost proxy = new HttpHost(validatorproxy, Integer.parseInt(validatorport), "http");
				logger.info("hostname:" + proxy.getHostName());
				logger.info("port:" + proxy.getPort());
				logger.info("SchemeName:" + proxy.getSchemeName());
				RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
				request.setConfig(config);
				response = httpclient.execute(request);
				logger.info("----------------------------------------");
				logger.info(response.getStatusLine().toString());
				// logger.info(EntityUtils.toString(response.getEntity()));
				logger.info("----------------------------------------");
				entity = response.getEntity();
				String result = EntityUtils.toString(entity);
				logger.debug(result + "成功啦!");

				int start = result.indexOf("<querySingleReturn>");
				int end = result.indexOf("</querySingleReturn>");
				result = result.substring(start + 19, end);
				result = Des2.decodeValue(validatorKey, result);
				logger.debug(result);
				dataSource = JaxbUtil.converyToJavaBean(result, DataSource.class);
			}
			if (dataSource != null && dataSource.getMessage() != null) {
				// -9967 "您无权查询数据（测试量已用完）"
				if ("-9967".equals(dataSource.getMessage().getStatus())) {
					logger.info("国政通身份验证次数已用完");
					// dataSource=JaxbUtil.converyToJavaBean(this.getXml(idCard,
					// fullName), DataSource.class);
				}
			}
			// 假数据
			// DataSource dataSource=null;
			if (dataSource == null || "-9967".equals(dataSource.getMessage().getStatus())) {
				dataSource = new DataSource();
				PoliceCheckInfos p = new PoliceCheckInfos();
				PoliceCheckInfo p1 = new PoliceCheckInfo();
				p1.setId(idCard);
				p1.setName(fullName);
				p1.setCompResult("国政通服务异常");
				p.setPoliceCheckInfo(p1);
				dataSource.setPoliceCheckInfos(p);
			}
			dataSource = this.getIDcardUrl(dataSource);
			return dataSource;
		} catch (Exception e) {
			logger.error("调用国政通身份证验证接口出错", e);
			throw new BusinessException(ID50001);
		} finally {
			if (entity != null) {
				try {
					EntityUtils.consume(entity);
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
					throw new BusinessException(ID50001);
				}
			}
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
					throw new BusinessException(ID50001);
				}
			}
		}
	}

	/**
	 * 不走代理直接访问id5服务器的方法
	 * 
	 * @param idCard
	 * @param fullName
	 * @return
	 */
	private DataSource queryByIdAndNameNewId5Service(String idCard, String fullName) {
		DataSource dataSource = null;
		String validatordummy = validatorMessageSource.getMessage(VALIDATOR_DUMMY, null, Locale.ROOT);
		if ("true".equals(validatordummy)) {
			dataSource = JaxbUtil.converyToJavaBean(this.getXml(idCard, fullName), DataSource.class);
		} else {
			CloseableHttpResponse response = null;
			String result = "";
			HttpEntity entity = null;
			// 1。https 连接上下文配置
			SSLContext sslContext = null;
			try {
				X509TrustManager x509TrustManager = new X509TrustManager() {
					@Override
					public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
					}

					@Override
					public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
					}

					@Override
					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}
				};
				sslContext = SSLContext.getInstance("SSL");
				sslContext.init(null, new TrustManager[] { x509TrustManager }, null);
			} catch (NoSuchAlgorithmException | KeyManagementException e1) {
				e1.printStackTrace();
			}

			String sslConfig = "TLSv1.1,TLSv1.2";
			String[] sslStringArray = sslConfig.trim().split(",");
			SSLConnectionSocketFactory ssf = new SSLConnectionSocketFactory(sslContext, sslStringArray, null,
					NoopHostnameVerifier.INSTANCE);
			httpNewClient = HttpClients.custom()
					.setSSLHostnameVerifier(SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER)
					.setSSLSocketFactory(ssf).build();
			// 2。连接参数配置
			HttpPost httpPost = new HttpPost(ID5URL);
			Id5NewDO id5NewDO = new Id5NewDO();
			id5NewDO.setFullName(fullName);
			id5NewDO.setIdCardNumber(idCard);
			id5NewDO.setApplicationCode("VTM");
			ObjectMapper obj = new ObjectMapper();
			String requestJson = "";
			try {
				requestJson = obj.writeValueAsString(id5NewDO);
			} catch (JsonProcessingException e1) {
				throw new BusinessException(ID50001);
			}
			StringEntity stringEntity = new StringEntity(requestJson, "UTF-8");
			stringEntity.setContentEncoding("UTF-8");
			stringEntity.setContentType("application/json");
			httpPost.setEntity(stringEntity);
			try {
				response = httpNewClient.execute(httpPost);
				entity = response.getEntity();

				result = EntityUtils.toString(entity);
				logger.error("Result is [" + result + "]");
			} catch (Exception e) {
				logger.error("调用国政通身份证验证接口出错", e);
				throw new BusinessException(ID50001);
			} finally {
				if (entity != null) {
					try {
						EntityUtils.consume(entity);
					} catch (IOException e) {
						logger.error(e.getMessage(), e);
						throw new BusinessException(ID50001);
					}
				}
				if (response != null) {
					try {
						response.close();
					} catch (IOException e) {
						logger.error(e.getMessage(), e);
						throw new BusinessException(ID50001);
					}
				}
			}
			dataSource = JaxbUtil.converyToJavaBean(result, DataSource.class);
			logger.error("chang to datasource [" + dataSource + "]");
			if (dataSource != null && dataSource.getMessage() != null) {
				// -9967 "您无权查询数据（测试量已用完）"
				if ("-9967".equals(dataSource.getMessage().getStatus())) {
					logger.info("国政通身份验证次数已用完");
				}
			}

			dataSource = this.getIDcardUrl(dataSource);
			logger.error("datasource to image is ok [" + dataSource + "]");
		}
		return dataSource;
	}

	// 模拟身份证验证
	private String getXml(String id, String name) {

		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<data>" + "<message>" + "<status>0</status>"
				+ "<value>处理成功</value>" + "</message>" + "<policeCheckInfos>" + "<policeCheckInfo " + "name=\"" + name
				+ "\" id=\"" + id + "\">" + "<message>" + "<status>0</status>" + "<value>查询成功</value>" + "</message>"
				+ "<name desc=\"姓名\">" + name + "</name>" + "<identitycard desc=\"身份证号\">" + id + "</identitycard>"
				+ "<compStatus desc=\"比对状态\">3</compStatus>" + "<compResult desc=\"比对结果\">一致</compResult>"
				// + "<compResult desc=\"比对结果\">一致</compResult>"
				+ "<checkPhoto desc=\"照片\">/9j/4AAQSkZJRgABAgAAAQABAAD//gAKSFMwMQVKAABvBgAGZAD/2wBDABcQEhUSDxcVExUaGRccIzsmIyAgI0gzNis7VUtaWFRLUlFeaodyXmSAZVFSdaB3gIuQl5mXW3GmsqSTsIeUl5H/2wBDARkaGiMfI0UmJkWRYVJhkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZGRkZH/wAARCADbALIDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDf1X/j2X/fH8jVi2/49ov9wfyqvqv/AB7L/vj+Rq4owoBOSB1oAWs67Zrm5W3j+6p+YgdD6/hVu5mEEJc9eij3qHTrfy4vMP3nH5CgC0iLGgVBhR0FUtTALwZ6ZOc/hV+qOoDM1sAcEt1/EUAXqKazBRk8CqF3qiQxnGNx4XmgCDUZg823OFTj8e9acRVYo13dFHP4VzFxeqtoAh+dmBP5HFOk1eV1CkAY9KAOlkmWNHZiPlGcVm6Z5U0zucZTovpXOzX00hVNxIXrmi3uXjlZ16hv0oA7OSRWhlxg4BGCeKzbSI3DhD/q1O4/5/CsKbU5sMN3zMOtXbLVBE/AJUnntxQB04AAAAwB0FZ98wS9iY9FAP6006rH5ijoM8024dbu9VIz2Az+tAFmwUuZJ3+85wPp/n+VXKaiqihVGFHQU6gCjd4+2QeuR/Or1Urv/j7t/qP51ZWaJ3Kq6lvTNABPKIYy55x0HrVexjb5pn+8/T6Uy6JuLhYEzhT8x7f5FXgAAABgDtQAtFFFAFHVV/co3cNj9KujOBng98VkXV4bhAmzaAQeufWpri9xbokTfOVG4jPy8UAEh+2Xir/yxjOCex//AF9K0QQQCDkHoRWNbwSXClVwqL1PqauaY7lHjbgIeBjkZzQBerHv7jzJxsb5U4Ujuat6hMwCwR/ek6/SsDWJDA0cUZwV+8QepoAuPrGbbZubevGcdaxJ7mS8n3yHIHfpVfeRuGc54qRF2rigBJzlR9aGfCA9z0oddwxTGXZyTk9qYArCPtz3pFbDMfWnqmEPHJFEQBU5APNACKpIZz3FLCTtP1qRh8p+lRxDCH60AStKy/MTVjS7xoblG6nnOemKoN877R0FPicrMxU84oA7WC8jmbYnJ9sYq3XM6XelZ1DHjp1wPyroZ5xFCX/AfWkBS1Bt86ouSQMY96bPCbUxMjHcRz9aFtpGt/OBYyE5684/xpk/nsFebPoM4H6UAXbKHZH5jcu/PPpVqiigAooooAzdVQARFVwBkZA/IVHPBGkq28ALOT8xbnFWNVx5SDHO7g0unwsA08n35On0oAswRLDEEXt1PqfWqliyq9033UBzx2HPpV+sNXd2eOMZ81vxNADbid1WS7BAYttTnn/OKwp90xO9iSa19bjEbRRh+EXpmsrOOBQBWiUZORyKlNRxZJY1LjNMBKiUb33HoKlaN3IRRyanW1K4VBSuOzIugNLAuU2jkk1aFptRmPYVJYW+EL+ppXKUSsygAYqn5ci5wDz3roDBx05qtNbEDcOlLmG4mUFCLz+NMj5djVh4zNJwDtHqKhVCkhH4VVyGiRDtIPBroNOlOoBV3ZWLqK5uRsDHc1s+G32XJjzyw5piOnqhqZGYxnnnj8qv1Su/+PuD6j+dIC7RRRQAUVSbUAGIEeRng7uv6UUAU72c3EmV/wBWvAOP8+lbAAAAAwB0ArMvIBBbRoOTuJJx/n+dalAEc77IHYHBCnB96paXEDulPb5RT9Rm+UQpyTy2OwqTTlC2qkfxEk/y/pQBz+vsx1BgWJAAx7Vmg1o68uNRkwOoH8qzhgDJ6UAMtx97JwOK0YkRYzIOQKqWUIcnPQdasxRM0hiB4zycelTJmkUTW0RYmVup6VbjhA6inKAAAOg4qQGszQjmQCF8n+E02xT9z9TUl1/x7v8Ah/OltP8Aj3T8f51QdSUiqd2SxEUfLN1xVuVxGhY9qq2qFiZnOWPSgGN+zKkYUDPvWTcL5cz5Hc1vkVk3EQadxjpzQhSWhnKpJ3t+FauhkDUEyM5z/Ks2ZiDtXqataKpXVIVPc1qYHZ1RuRm/h/D+dXqpXGft8WBngfzNIC7Va9kKRhFBLScDFWGIVSx6AZNU4M3FyZmHypwvFADV08lQTJg45G3p+tFX6KAKOqLmJG9Gx/n8qstOiQCVjhSMgdzTL2JpoCqDLAggVUhhnnKJNuESY4YY/CgCPYZLee5k6sQF/Mf/AKq0LIYtI8HPH9ahvpohA8IOHGMKB9KsWoxbR5OflFAHPeIVIvQT0K8Vjcu4QdO9dB4nAWOF888gVi2sWR7mgY6KKRSSnQ+hq3ZjbOwPUAj9aVMKOelQwS/6RIfr/Ooeppsai81IBzVMXe08qcfSrcM8b9DU2KuF0P8AR3/D+dVFaYRblO1F9D/n1qe4lMrmND8qglvwqIXBWAxYIbp+FMQBmuTHGeg5Y4q5tCgAdBxVW2nWOJvlJYt2p3nzt0i4oGmTE1nMcSzMegJH45qeRpMjg1Ui3Ty4bIycmiwmyr5RyXbqas6Wn/EziIPQ8/nVi8jUJuHSotKAGoKTwABz+Iq0zNqx1bMqDLMFHucVSuGH2uFwQV4+bt1pDuvZiAcRIe1Rx26m4khY4x9055pkkl1P5zeVGflHJb1xUa3MiKPLXEY4weefrR5QM3kRE/7bEf54q1coEs2VegAH60AWEYOgYdCM0VlrdTKoUPwBgcCigDVqC7mEEJOfnPCipiQASTgDqTWfCDeXRldf3a8DI/IUARy2+LTz3O6RyGyOgzV2zbNojMegPPsKL/8A49JPw/mKpRzNJAlrGPmPViffNAGZql2l/IY16IflyODVe2HBNSTwCF5I+u0nB9aS0H7v8am+hdrMV1yeabavFG8jue/FWSuRVWyjDSu56+9K5di6L21bgk+nIpJiqRGSIr7YqOOyAm3EjGc4pfL8+6OFHl55wOAaH5Ar9Sxp4xDu7tU08aCJ2CrnaecVHD8r4H3amuT+4b/dNQUUbUgRk/7VIb9VYqFJIGfQVLbxbrcY9aJLNZmDSEgjvVIT8iJ74eVuKFC/3feiyAKMw55xUc6iVtijKRqcDHFT2CbYTx/FQxDrlcwN9KowFlUeX36nA/KtKbAidj0C1l6fk7Ce7CmthNanVWsflQKMYbGSPeqdxI0V47LjOMcj2rRJAGScAVnKVuL0Ej5Sen0FWZFmzh8uPcww7evYU68/49n/AA/nU9QXpAtm564/nQBRWJSoJfGR/s/40VFRQBd1CQkJAnLOef6frVmCIQxBF5x1Pqaq2MbO7XMnVvu1eoAgvTttZCPTH60yy2pZhyAOCWOPQmlvzi1YepA/Wqsjb4obaLqQC348/wD16AMXUw1zdyyDhew/Co9PbMOPRq1dXtAiRPFwB8prH0/5Vb6ipLRqKM1DYICX/CnpKqkBmAJ9aS0dYnkVzj6+1SaE1w4ijwPvNwKkgi8mLafvHk1U8wmTznU/7A7VIs8isVl6kenSgLky/eqS4YCA5OMggVXhY5y3Apkmbh3bPyIDikNkljKv+rIweoPrU123lx/L1bgVnwSbJ0zgYODV2Im5n8w5CJ0BpiQqQ+VauD94qSaZZj90f96rZAYEHoeDWdvkiBiAIZjQAl2/mN5YOADyagtwi+WQRt4/nSld25FPGMsc1Lp9uj3HlOeMHjNMk2Z5jMwhhOd3Vs/pUcMXl320HO0dfwq3DAkOduST3NVxn+0j06f0qzIu1n3025vLXop5+tW7iXyYi3U9APeqEiFIVZuWkOfXj/JoA0YhiJAOcKKKfRQAiqFUKvAAwKWiigCnqX/Huv8Av/0NJp8GxPNbqw49hUOoTb5fLU/KnX61pAAAADAHagDP1hsWwXGcnr6Vzdu4jVz34wK7KREdCJACvfNcrLAPtJO0BMAgAdaTKTGpEWiMjH5jzVmCKNoPMckY64NIf9U/+6ajhLOoiHALZNQaIuWqeY5kYfKOFB7VDqGVuoiM4OKvRgIoUdBVS7ZTcJvGQBz+tAyG7ufLKxqjc/xY4xVhJdltsWNpMjkAdar20e+TzD07ZrR5wQKBmYF3SovIJbjI5FayRiJQi9BVGQBbuM454/nWjnPWgSENVLyTaNi/eb27VZdgASegqpCDNK0rDgcAUDYiRiNMcZ7mpLFSNRGM/d5+mKUgk4HU8Cr0aj+0Gx0Uf0FUkZNl2qMrCK/DtnBGf0xV6mSRpIMOoNUQVQDdz7iP3S8fWnXq7nhX1JH8qkldbaHCgf7IzVNvMjkiaYk87sE5IoA06KKKACobqXyYWYfePA+tOglE0QccZ6j0qpKTdXgiB/dp94fz/wAKAKzwsFiZj80pJ9fStiqOo/fh+p/p61bmkWKMu3boPU0AVb2QsRbxjLNycfyrKmiJjMoA4IBNaNo8YczTSDzGOBn+ftUSGNVuIpsgN6D0zQCMt3CxnPUjAFPsQNrN3ziqZDM8m/8Ah4qzaN+7P1rNmqLxbFZ92+6fBPTAFW3dRGW9BVKJfMn3EDOM9KSKZYSZY8KnYVN9q44IpsYC9RUyNEe4+lAys04a6j7HirwIPQ5rOvE/fLtAzj0pE32soJ5yORnrTFctXUmQIl5JPNSoAkYUdqggG4mV+p6VMWoBk1pHvuAccLyaswHN9KfY/wAxS6eqC3Dqclupplt/x+y/j/OrRi3dl6kYhVJPQDJpaqXjszCFOSetMQ2EG4uDKfuqeB/KjUBzGfrVqKMRIFXt1PrVbUMbU9cmgCyZYwcF1BHvRVX7D/00/wDHaKAK8Fx5Ns4B+dm+UenvV2yh8mIEj525NVdOiV5GdudmMD3rSoAqahE0iKyAkqegHrVaWSSVTJLxGpxs/wBrFalZ4H225yf9Unv1oAYLZnt2mc/NjIHTimYiFm1xLuPl8EZ+9WlP/qJP90/yrm9SnItY4R0Llj+QxQBUVt0DHPds06zfCH61XiPLL/epkcmwMO/apaLTNGRjJIsSn6063A+0OOwBH61BaNsOW+8antmHmSn3qWi7l5YweopxjiRSxXgUxZKhllM0giXoOSakZE27eJmHBNJM5lYdl7f1q98oXaANvpVa5KholUADPSmInYbRgHiq00u2KRs4wOKGcyNgdKZdj9z5frTQMv6BMWgMDnlRuH49f8+9WBN5M0xAySxx+dZOmXHkXingIVK/4f0rWtSr3LO4HQt7A1oYk8d4DEzOBuXsD1pLOPOZn5LE4/xquqLNclV4Qkn8K0gABgDAFAC1UvV3PCvqSP5VbqjeMVuEIx8oB/WgC2ZYwcF1BHvRWb5cjc7HOec4PNFAFjTP9W/1q7VHT2RLd2bA+br+FMudWghHyfvD7dKAJ76YRxFAfmfjHtTUlhsoAJZFU9SM85rnZL+4u52lJ2AdAO1RPJnJJyaANa+1kmN1t4+CCNzf4VhNO0+Hc5/pT5TmI/SoIeYwKYDhwamAU84GahByMGlMhA2dzSY0xXJdti/jT7V2Bbmpo4NqD171HAoWRtxwADUlkzzsin5ue1EBdVznk0Q2/nvvbG0dquCz+tK5RB58gqCUs8qZ9aveQq9uaglAFxH6cfzpXBk8ahFyapXEvmE46U+4n38L93+dVJX2pn+KrSM2xjnfKFB4HWr0d3KgBZjIvTDdR+NUI12Ic/eapkPbqDVEnQ2E8U10PIJwByp6jjv+NatcPGSl1uVipHQg4IrXtNXnhws481PXuP8AGkB0NUpQJr0J2HB9+9J/aVvJFmKQb24CngimWqkXK59M/pQBo0UUUAcK0k1xhXkJUc47UzexUJ70gYxlhjmnwqAzZOCKYyVchQB2pmcZFPNNxQIa4PlmmRcEe9Tyf6o1XLYUADp0oAdJ8vzHvTI/nJY0rt5uFWhVIyo60AXracA7ZOPQ09YBLO4OQAT0qhuI4NaGnPthkkJJxjqOnX/CokupcX0Jnb7Mo2gE9hT4blyxR87u1LbRhyZXHOeKhvZTb3SYTlhwTUpXKvYsyERruk4rKupjJcKe2OlOlmaY5kJNQOf3q4q1GxDdyb/aqsp8yTJHAp0zgYXqx6CmK+wYxye9USSEbm9hT8jHTHvSqNiY70jtsQeuOKAI1P79vXFShh3qs2Q2T165qZ3xGM8E0DEwZZRjoKtWuoTW11kHcgH3W9Pb0qvEgRcnljTGf99yPloA6Qa3Dj7kn5D/ABornDMuen60UAEjDcoxk05EKsxI696IVBYu33u1S0AM2jvTT1p0xwhwcGmp0TPPFABK2E29zUeAID6mpUj+YljnK01o0UH5uewJoAZAmRu/iNOcYINEXCg1JIPyoEQP1Bq3YIZFVAeoOePf/wCvVRvkHtWpoyZi3Z9R19//AK1J7DW5cJEcRx0VaytQkdpICxJwABnHoPSta6UiFqyL7ASJh6L2x2H+FTEuRC7ncFTrTQWb/eWnRjaMnqaYRiRsnFWQR4Jf1Y9KmMYWPPpTokI57mnS/wCrNACIc7BTQPMcseg6UgOI8Dq1SIu0KPegCGYYfPrRGrEhm7dKkl+50oT7o+lAC/pSMgb71L7UyQ4GB1NADN0XoaKBGMfeooAsKeMCnVVjdjPjPG41aFAEdx/q/wAaROSv0on/ANWPrRH/AA/SgCYkAZPSoEBdy57dKfN9z8RSxDC/hQArLTWbAUYzmndqimoERTq2eOimtnRQ32bBHb19z/jWXJ0atGxJFupBIO5un/AaTGtDTkQtGykYBFc/OS64cEbWAHOexrobj/jzT/a25/KsO8AB+rKf0NJKw27kJ4NR43SHvTpe/wBKbb/6z8KoROePxqOf7oFP7mopP60AEK5wx7dKlP8AKhPuD6Up70AMl+5SKPlH0om+7+NNLEbcHsKAHYqLO9yx6DpUk5wnHFRp0FAD8H2/OipMCigD/9k=</checkPhoto>"
				// +"<checkPhoto desc=\"照片\"></checkPhoto>"
				+ "<no desc=\"唯一标识\" />" + " </policeCheckInfo>" + "</policeCheckInfos>" + "</data>";
		return xml;
	}

	@SuppressWarnings({ "static-access" })
	public DataSource getIDcardUrl(DataSource dataSource) {
		InputStream is = null;
		InputStream in = null;
		try {
			String imgStr = dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getCheckPhoto();
			Font font = LoadFontSingleton.getIstance();
			font = font.deriveFont(Font.BOLD, 15);

			if (imgStr == null || "".equals(imgStr)) {
				BufferedImage Image1 = new BufferedImage(180, 219, BufferedImage.TYPE_INT_BGR);
				BufferedImage ImageOne = new BufferedImage(Image1.getWidth() + 200, Image1.getHeight(),
						BufferedImage.TYPE_INT_BGR);
				// 2.获取图片的画布
				Graphics2D g = (Graphics2D) ImageOne.getGraphics();
				Graphics2D g1 = (Graphics2D) Image1.getGraphics();
				g1.setBackground(Color.WHITE);
				g1.clearRect(0, 0, Image1.getWidth() + 200, Image1.getHeight());
				// 3.在画布的指定位置上画文字
				g.setBackground(Color.WHITE);
				g.clearRect(0, 0, Image1.getWidth() + 200, Image1.getHeight());
				g.setColor(Color.BLACK);
				g.setFont(font);
				g1.setFont(font);

				// g.setFont(new Font("黑体", Font.CENTER_BASELINE, 12));
				g.drawString(dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getName(), 30, 40);
				g.drawString(dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getId(), 30, 70);

				if ("2".equals(dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getCompStatus())) {
					logger.debug(dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getCompResult());
					g.drawString("号码与姓名" + dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getCompResult(), 30,
							100);
				} else {
					g.drawString(dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getCompResult(), 30, 100);
				}
				in = this.merge(Image1, ImageOne, 1);
			} else {
				Base64 base64 = new Base64();
				byte[] bytes = base64.decodeBase64(new String(imgStr).getBytes());
				for (int i = 0; i < bytes.length; ++i) {
					if (bytes[i] < 0) {// 调整异常数据
						bytes[i] += 256;
					}
				}
				is = new ByteArrayInputStream(bytes);
				BufferedImage ImageTwo = ImageIO.read(is);
				// 调整身份证大小
				if (ImageTwo.getHeight() < 219 || ImageTwo.getHeight() > 230) {
					BufferedImage ImageTwo2 = this.switchImg(ImageTwo);
					ImageTwo = ImageTwo2;
				}
				BufferedImage ImageOne = new BufferedImage(ImageTwo.getWidth() + 200, ImageTwo.getHeight(),
						BufferedImage.TYPE_INT_BGR);
				// 2.获取图片的画布
				Graphics2D g = (Graphics2D) ImageOne.getGraphics();
				// 3.在画布的指定位置上画文字
				g.setBackground(Color.WHITE);
				g.clearRect(0, 0, ImageTwo.getWidth() + 200, ImageTwo.getHeight());
				g.setColor(Color.BLACK);
				g.setFont(font);
				// g.setFont(new Font("黑体",Font.CENTER_BASELINE,12));
				g.drawString(dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getName(), 30, 40);
				g.drawString(dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getId(), 30, 70);
				g.drawString("号码与姓名" + dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getCompResult() + "且照片存在",
						30, 100);
				in = this.merge(ImageTwo, ImageOne, 1);
			}
			String upload = this.getUploadpath(dataSource.getPoliceCheckInfos().getPoliceCheckInfo().getId(), in);
			dataSource.setIdUrl(upload + "?" + new Date());
		} catch (Exception e) {
			logger.error("国政通:" + e.getMessage(), e);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}

		}
		return dataSource;
	}

	/**
	 * 图片拼接
	 * 
	 * @param files
	 *            要拼接的文件列表
	 * @param type
	 *            1 横向拼接， 2 纵向拼接
	 * @return
	 */
	public InputStream merge(BufferedImage img1, BufferedImage img2, int type) {
		BufferedImage[] images = new BufferedImage[2];
		images[0] = img1;
		images[1] = img2;
		int len = images.length;
		if (len < 1) {
			logger.info("图片数量小于1");
			return null;
		}

		int[][] ImageArrays = new int[len][];
		for (int i = 0; i < len; i++) {

			int width = images[i].getWidth();
			int height = images[i].getHeight();

			ImageArrays[i] = new int[width * height];// 从图片中读取RGB
			ImageArrays[i] = images[i].getRGB(0, 0, width, height, ImageArrays[i], 0, width);
		}

		int newHeight = 0;
		int newWidth = 0;
		for (int i = 0; i < images.length; i++) {
			// 横向
			if (type == 1) {
				newHeight = newHeight > images[i].getHeight() ? newHeight : images[i].getHeight();
				newWidth += images[i].getWidth();
			} else if (type == 2) {// 纵向
				newWidth = newWidth > images[i].getWidth() ? newWidth : images[i].getWidth();
				newHeight += images[i].getHeight();
			}
		}

		logger.info("拼接后图像宽度：" + newWidth);
		logger.info("拼接后图像高度：" + newHeight);
		if (type == 1 && newWidth < 1) {
			logger.info("拼接后图像宽度小于1");
			return null;
		}
		if (type == 2 && newHeight < 1) {
			logger.info("拼接后图像高度小于1");
			return null;
		}
		ByteArrayOutputStream out = null;
		// 生成新图片
		try {
			BufferedImage ImageNew = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_RGB);
			int height_i = 0;
			int width_i = 0;
			for (int i = 0; i < images.length; i++) {
				if (type == 1) {
					ImageNew.setRGB(width_i, 0, images[i].getWidth(), newHeight, ImageArrays[i], 0,
							images[i].getWidth());
					width_i += images[i].getWidth();
				} else if (type == 2) {
					ImageNew.setRGB(0, height_i, newWidth, images[i].getHeight(), ImageArrays[i], 0, newWidth);
					height_i += images[i].getHeight();
				}
			}

			out = new ByteArrayOutputStream();
			ImageIO.write(ImageNew, "jpg", out);// 图片写入到输出流中

			return new ByteArrayInputStream(out.toByteArray());

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		} finally {
			if (out != null) {
				try {
					out.flush();
					out.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}

	/**
	 * 获得上传 图片根路径
	 * 
	 * @return
	 */
	private String getUploadRootPath() {
		return contentRepositoryRootPath + REPOSITORY_TEMP;
	}

	/**
	 * 查询结束后返回图片保存路径
	 */
	private String getUploadpath(String folderName, InputStream in) {

		String folderNamePath = SERVICE_CONTENT + REPOSITORY_TEMP + File.separator + UPLOAD + File.separator
				+ folderName + File.separator;
		logger.debug(folderNamePath);
		String filename = folderNamePath + folderName + "_IDcheck.jpg";
		FileOutputStream out = null;
		try {
			String uploadPath = this.getUploadRootPath();
			String dirpath = uploadPath + File.separator + UPLOAD + File.separator + folderName;
			logger.debug(dirpath);
			File folderNameDir = new File(dirpath);
			if (!folderNameDir.exists()) {
				folderNameDir.mkdirs();
			}
			String filepath = dirpath + File.separator + folderName + "_IDcheck.jpg";
			logger.debug(filepath);
			File sos = new File(filepath);
			out = new FileOutputStream(sos);
			FileCopyUtils.copy(in, out);
			filename = filename.replaceAll("\\\\", "/");
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return null;
		} finally {
			if (out != null) {
				try {
					out.flush();
					out.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
		return filename;

	}

	/*
	 * 国政通身份证照片转化方法
	 */
	public BufferedImage switchImg(BufferedImage img1) {
		BufferedImage buffImg = null;
		buffImg = new BufferedImage(180, 219, BufferedImage.TYPE_INT_BGR);
		buffImg.getGraphics().drawImage(img1.getScaledInstance(180, 219, Image.SCALE_SMOOTH), 0, 0, null);
		return buffImg;
	}
}
